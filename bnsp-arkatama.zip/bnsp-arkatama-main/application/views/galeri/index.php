<!-- Begin Page Content -->
<div class="container-fluid">
    <div>
        <!-- Page Heading -->

        <br>
        <div style="text-align: center;">
            <div>
                <img src="<?= base_url('assets/img/kajian-1.jpg') ?>" height="250px">
                <img src="<?= base_url('assets/img/kajian-2.jpg') ?>" height="250px">
            </div>
            <br>
            <div>

                <img src=" <?= base_url('assets/img/touring-1.jpg') ?>" height="250px">
                <img src=" <?= base_url('assets/img/touring-2.jpg') ?>" height="250px">
            </div>
        </div>


        <!-- /.card -->
    </div>
    <!-- /.col -->
</div>
<!-- /.container-fluid -->