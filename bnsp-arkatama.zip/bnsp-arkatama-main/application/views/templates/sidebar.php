        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard">
                <div class="sidebar-brand-icon ">
                    <img src="<?= base_url('assets/img/logo.png') ?>" alt="" width="150" height="80" wid>

                </div>
            </a>
            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">
            <div class="sidebar-heading">
                Dashboard
            </div>

            <li class="nav-item">
                <a class="nav-link" href="home">
                    <span>Home</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="artikel">
                    <span>Artikel</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="event">
                    <span>Event</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="galeri">
                    <span>Galery Foto</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="klien">
                    <span>Klien Kami</span></a>
            </li>
            <hr class="sidebar-divider d-none d-md-block">
            <div class="sidebar-heading">
                Login
            </div>
            <li class="nav-item">
                <a class="nav-link" href="sign">
                    <span>Sign In</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="sign">
                    <span>Sign Up</span></a>
            </li>


            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">



        </ul>