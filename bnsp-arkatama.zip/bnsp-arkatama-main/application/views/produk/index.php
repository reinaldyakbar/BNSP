<!-- DataTables -->
<link rel="stylesheet" href="{{ asset('cpanel/vendor/datatables/dataTables.bootstrap4.css') }}">
<!-- Content Header (Page header) -->
<div class="col-sm-12">

</div>
<!-- Main content -->
<div class="section">
    <div class="container">
        <h3 class="py-3">Merchandise Muslim Biker Indonesia</h3>
        <nav class="navbar navbar-expand-lg bg-danger">
            <div class="container">
                <div class="navbar-translate">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#example-navbar-danger" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar bar1"></span>
                        <span class="navbar-toggler-bar bar2"></span>
                        <span class="navbar-toggler-bar bar3"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse has-image" id="example-navbar-danger" style="background: url(&quot;https://muslimbiker.id/assets/img/blurred-image-1.jpg&quot;) 0% 0% / cover;">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">

                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="row">
            <div class="col-lg-3 col-sm-6 my-3">
                <div class="card">
                    <img class="card-img-top" src="https://muslimbiker.id/public/storage/Merch/15f08ae8-1440-4125-b63a-aab6db5ebfc9/YlYbUgTiznqzyCUFdqGCs1tI7LToZPGbyoJHeqgj.jpg" alt="T-shirt Oficial MBI Vol. 3">
                    <div class="card-body">
                        <h5 class="card-text mb-3">T-shirt Oficial MBI Vol. 3</h5>
                        <p class="card-text">
                            Rp. 120,000 <br>
                        </p>
                        <footer class="blockquote-footer">Stock barang : <b>99</b></footer>
                        <p></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 my-3">
                <div class="card">
                    <img class="card-img-top" src="https://muslimbiker.id/public/storage/Merch/b1fe8e91-abcc-469e-b069-0427bf305fd5/aZlxMwFH1CF4CpgxyXMJ5P4rf7qOzj01m8oYY8dj.jpg" alt="T-shirt Oficial MBI Vol. 2">
                    <div class="card-body">
                        <h5 class="card-text mb-3">T-shirt Oficial MBI Vol. 2</h5>
                        <p class="card-text">
                            Rp. 120,000 <br>
                        </p>
                        <footer class="blockquote-footer">Stock barang : <b>99</b></footer>
                        <p></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 my-3">
                <div class="card">
                    <img class="card-img-top" src="https://muslimbiker.id/public/storage/Merch/ca75f38e-279e-4238-b3f1-ae36c4571666/89LrLh7lMTQiEvqkHp1uFV0BOvlAvFDonpnCAmSo.jpg" alt="T-shirt Oficial MBI Vol. 1">
                    <div class="card-body">
                        <h5 class="card-text mb-3">T-shirt Oficial MBI Vol. 1</h5>
                        <p class="card-text">
                            Rp. 120,000 <br>
                        </p>
                        <footer class="blockquote-footer">Stock barang : <b>99</b></footer>
                        <p></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 my-3">
                <div class="card">
                    <img class="card-img-top" src="https://muslimbiker.id/public/storage/Merch/b8565b8e-b7db-48c8-a18e-f94449723e9f/N24DxFQGhuR2uP9f5eeQGhbOtmCNoFF5LEXiiFdE.jpg" alt="T-shirt it's Akhlaq">
                    <div class="card-body">
                        <h5 class="card-text mb-3">T-shirt it's Akhlaq</h5>
                        <p class="card-text">
                            Rp. 120,000 <br>
                        </p>
                        <footer class="blockquote-footer">Stock barang : <b>99</b></footer>
                        <p></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 my-3">
                <div class="card">
                    <img class="card-img-top" src="https://muslimbiker.id/public/storage/Merch/7fd7262a-82cb-4d6d-8d54-136f9154b30d/9tHGIL1uwoHUWcA3drJ7DpEZIFtK0YTkdfZD5Ejc.jpg" alt="Topi Trucker Hitam">
                    <div class="card-body">
                        <h5 class="card-text mb-3">Topi Trucker Hitam</h5>
                        <p class="card-text">
                            Rp. 50,000 <br>
                        </p>
                        <footer class="blockquote-footer">Stock barang : <b>99</b></footer>
                        <p></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 my-3">
                <div class="card">
                    <img class="card-img-top" src="https://muslimbiker.id/public/storage/Merch/02168977-9067-4f12-a2d0-4f6fd342ca2b/6j1I0umRJfaj1Z3Wwo7pbZz7J7Uc2TV9KR3nOq7q.jpg" alt="Topi Trucker Putih">
                    <div class="card-body">
                        <h5 class="card-text mb-3">Topi Trucker Putih</h5>
                        <p class="card-text">
                            Rp. 50,000 <br>
                        </p>
                        <footer class="blockquote-footer">Stock barang : <b>99</b></footer>
                        <p></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 my-3">
                <div class="card">
                    <img class="card-img-top" src="https://muslimbiker.id/public/storage/Merch/c6a1cec6-2396-4e12-ae8e-e4b0328859f9/knZ5xylbHPTDVNMNc9d4mGTc80C4jEurEySTSosQ.jpg" alt="Pin Cor">
                    <div class="card-body">
                        <h5 class="card-text mb-3">Pin Cor</h5>
                        <p class="card-text">
                            Rp. 35,000 <br>
                        </p>
                        <footer class="blockquote-footer">Stock barang : <b>99</b></footer>
                        <p></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 my-3">
                <div class="card">
                    <img class="card-img-top" src="https://muslimbiker.id/public/storage/Merch/62f945d8-25b8-4e3e-882d-f405f665fac8/8UrcAPt7RAW5CJ2HD4BVdUG5fkldHGIlh0n5gwPl.jpg" alt="Bordir Jaket / Rompi">
                    <div class="card-body">
                        <h5 class="card-text mb-3">Bordir Jaket / Rompi</h5>
                        <p class="card-text">
                            Rp. 75,000 <br>
                        </p>
                        <footer class="blockquote-footer">Stock barang : <b>99</b></footer>
                        <p></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 my-3">
                <div class="card">
                    <img class="card-img-top" src="https://muslimbiker.id/public/storage/Merch/47a933e9-3283-4fa1-ae56-f709ea0855bc/R4zI3seld4kNlwNp1vJcNh2pTAaTeDMoYVDi4oZt.jpg" alt="Stiker Official">
                    <div class="card-body">
                        <h5 class="card-text mb-3">Stiker Official</h5>
                        <p class="card-text">
                            Rp. 10,000 <br>
                        </p>
                        <footer class="blockquote-footer">Stock barang : <b>99</b></footer>
                        <p></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><!-- DataTables -->
<script src="{{ asset('cpanel/vendor/datatables/jquery.dataTables.js') }}"></script>
<script src="{{ asset('cpanel/vendor/datatables/dataTables.bootstrap4.js') }}"></script>
<!-- Page Script -->
<script>
    $(document).ready(function() {
        var table = $('#table-data').DataTable();

        $('.dataTables_filter input').unbind().bind('keyup', function() {
            var colIndex = document.querySelector('#table-data-filter-column').selectedIndex;
            table.column(colIndex).search(this.value).draw();
        });
    });
</script>