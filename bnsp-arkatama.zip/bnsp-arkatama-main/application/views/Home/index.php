<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <p style="text-align:justify"><img style=" float: left; margin:0.1px 20px 50px" src="<?= base_url('assets/img/touring-1.jpg') ?>" width="550px">
    <h2><b>MUSLIM BIKER INDONESIA</b></h2>
    <h3>
        Sekilas tentang kami.
    </h3>
    <a>
        Muslim Biker Indonesia (MBI) adalah wadah biker untuk belajar tentang keislaman, bagaimana menjadi muslim yang benar-benar hanya beribadah kepada Allah dan mengetahui cara beragama yang sesuai tuntunan Rasulullah shallallahu alaihi wa sallam.

        MBI terbuka untuk semua biker, mulai dari motor dengan cc kecil sampai besar, mulai dari pecinta motoran sampai dengan anak komunitas dan club motor. Secara bentuk MBI bukanlah sebuah komunitas layaknya kelompok motor lain dan juga club motor.
        MBI dibentuk pada Oktober 2017 atas kebutuhan para biker. Mereka berkumpul untuk menemukan cara mendekatkan diri kepada Allah dan mendapat ilmu tentang cara beribadah yang selayaknya dilakukan berdasarkan contoh dari Rasulullah shallallahu alaihi wa sallam.
        Selayaknya wadah silaturahmi para biker, MBI pun sering mengadakan kegiatan riding ke beberapa daerah dan tempat yang direncanakan.</h3>

        </p>




</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->