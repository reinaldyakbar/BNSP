<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <h2><b>MUSLIM BIKER INDONESIA</b></h2>
    <a>
        Muslim Biker Indonesia (MBI) adalah wadah biker untuk belajar tentang keislaman, bagaimana menjadi muslim yang benar-benar hanya beribadah kepada Allah dan mengetahui cara beragama yang sesuai tuntunan Rasulullah shallallahu alaihi wa sallam.

        MBI terbuka untuk semua biker, mulai dari motor dengan cc kecil sampai besar, mulai dari pecinta motoran sampai dengan anak komunitas dan club motor. Secara bentuk MBI bukanlah sebuah komunitas layaknya kelompok motor lain dan juga club motor.
        MBI dibentuk pada Oktober 2017 atas kebutuhan para biker. Mereka berkumpul untuk menemukan cara mendekatkan diri kepada Allah dan mendapat ilmu tentang cara beribadah yang selayaknya dilakukan berdasarkan contoh dari Rasulullah shallallahu alaihi wa sallam.
        Selayaknya wadah silaturahmi para biker, MBI pun sering mengadakan kegiatan riding ke beberapa daerah dan tempat yang direncanakan.</h3>

        </p>




</div>
<!-- /.container-fluid -->
<form>
    <table>
        <tr>
            <td>
                Tulis Komentar</td>
            <td><textarea cols="30" rows="5"></textarea></td>
        </tr>

        <tr>
            <td><input type="submit" value="Tuliskan Komentar " /></td>
            <td><input type="reset" value="hapus Komentar"></td>
        </tr>
    </table>
    </td>
    </tr>
</form>

</div>
<!-- End of Main Content -->