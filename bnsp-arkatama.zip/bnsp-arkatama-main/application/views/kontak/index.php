<!-- Begin Page Content -->
<div class="container-fluid">
    <div>
        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
        <div>
            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7931.502414725922!2d106.825144!3d-6.29639!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x6c9280b74d13641e!2sMuslim%20Biker%20Indonesia!5e0!3m2!1sid!2sid!4v1671560853614!5m2!1sid!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" width="1260" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            <!-- /.card-body -->
        </div>
        <br>
        <ul class="navbar-nav ml-center">
            <section class="contact-information-area section-padding-80-0">
                <div class="container" style="text-align:center">
                    <div class="row">
                        <!-- Single Contact Information -->
                        <div class="col-12 col-sm-6 col-lg-3">
                            <div class="single-contact-information mb-80">
                                <i class="fa fa-phone"></i>
                                <h4>Phone</h4>
                                <p>+62 821 1010 2004</p>
                            </div>
                        </div>

                        <!-- Single Contact Information -->
                        <div class="col-12 col-sm-6 col-lg-3">
                            <div class="single-contact-information mb-80">
                                <i class="fa fa-home"></i>
                                <h4>Address</h4>
                                <p>Jl. A. Natasukarya No.30 Subang, Jawa Barat. 41214</p>
                            </div>
                        </div>

                        <!-- Single Contact Information -->
                        <div class="col-12 col-sm-6 col-lg-3">
                            <div class="single-contact-information mb-80">
                                <i class="fa fa-clock"></i>
                                <h4>Open time</h4>
                                <p>Everyday Open</p>
                            </div>
                        </div>

                        <!-- Single Contact Information -->
                        <div class="col-12 col-sm-6 col-lg-3">
                            <div class="single-contact-information mb-80">
                                <i class="fa fa-envelope"></i>
                                <h4>Email</h4>
                                <p>info@tiger-club.or.id</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </ul>

        <!-- /.card -->
    </div>
    <!-- /.col -->
</div>
<!-- /.container-fluid -->