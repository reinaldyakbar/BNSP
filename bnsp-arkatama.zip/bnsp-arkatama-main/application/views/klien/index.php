</div>
<!-- Main content -->
<div class="section">
    <div class="container">
        <h3 class="py-3">Klien Muslim Biker Indonesia</h3>
        <nav class="navbar navbar-expand-lg bg-danger">
            <div class="container">
                <div class="navbar-translate">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#example-navbar-danger" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar bar1"></span>
                        <span class="navbar-toggler-bar bar2"></span>
                        <span class="navbar-toggler-bar bar3"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse has-image" id="example-navbar-danger" style="background: url(&quot;https://muslimbiker.id/assets/img/blurred-image-1.jpg&quot;) 0% 0% / cover;">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">

                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="row">
            <div class="col-lg-3 col-sm-6 my-3">
                <div class="card">
                    <img class="card-img-top" src="https://akcdn.detik.net.id/visual/2021/06/07/gilang-widya-pramana_169.jpeg?w=650">
                    <div class="card-body">
                        <h5 class="card-text mb-3">Gilang Widya Permana</h5>
                        <p></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 my-3">
                <div class="card">
                    <img class="card-img-top" src="https://akcdn.detik.net.id/visual/2021/12/01/keterangan-pers-menteri-bumn-1_169.jpeg?w=650">
                    <div class="card-body">
                        <h5 class="card-text mb-3">Erick Thohir</h5>
                        <p></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>