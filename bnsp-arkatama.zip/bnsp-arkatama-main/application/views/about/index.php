<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <p style="text-align:justify"><img style=" float: left; margin:0.1px 20px 50px" src="<?= base_url('assets/img/about.png') ?>" width="550px">
    <h2><b>Tentang Muslim Biker Indonesia</b></h2>
    <h3>
        Sekilas tentang kami.
    </h3>
    <a>
        Muslim Biker Indonesia (MBI) adalah wadah biker untuk belajar tentang keislaman, bagaimana menjadi muslim yang benar-benar hanya beribadah kepada Allah dan mengetahui cara beragama yang sesuai tuntunan Rasulullah shallallahu alaihi wa sallam.

        MBI terbuka untuk semua biker, mulai dari motor dengan cc kecil sampai besar, mulai dari pecinta motoran sampai dengan anak komunitas dan club motor. Secara bentuk MBI bukanlah sebuah komunitas layaknya kelompok motor lain dan juga club motor.
        MBI dibentuk pada Oktober 2017 atas kebutuhan para biker. Mereka berkumpul untuk menemukan cara mendekatkan diri kepada Allah dan mendapat ilmu tentang cara beribadah yang selayaknya dilakukan berdasarkan contoh dari Rasulullah shallallahu alaihi wa sallam.
        Selayaknya wadah silaturahmi para biker, MBI pun sering mengadakan kegiatan riding ke beberapa daerah dan tempat yang direncanakan. Tidak sedikit juga kegiatan MBI dilakukan melalui kegiatan touring sambil diskusi tentang keislaman.</h3>

        </p>
        <br>
        <br>
        <div>
            <p>
            <h1 style="text-align: center;"><b>SEJARAH</b></h1>
            </p>
            <a>Muslim Biker Indonesia (MBI) adalah wadah biker untuk belajar tentang keislaman, bagaimana menjadi muslim yang benar-benar hanya beribadah kepada Allah dan mengetahui cara beragama yang sesuai tuntunan Rasulullah shallallahu alaihi wa sallam.</a>
            <div style="text-align: justify;">
                <a>
                    <b>A. Sekilas tentang Muslim Biker Indonesia</b><br>
                    MBI terbuka untuk semua biker, mulai dari motor dengan cc kecil sampai besar, mulai dari pecinta motoran sampai dengan anak komunitas dan club motor. Secara bentuk MBI bukanlah sebuah komunitas layaknya kelompok motor lain dan juga club motor.
                </a>
            </div>
            <div style="text-align: justify;">
                <a>
                    <b>B. Tujuan</b><br>
                    MBI dibentuk pada Oktober 2017 atas kebutuhan para biker. Mereka berkumpul untuk menemukan cara mendekatkan diri kepada Allah dan mendapat ilmu tentang cara beribadah yang selayaknya dilakukan berdasarkan contoh dari Rasulullah shallallahu alaihi wa sallam.<br>

                    Pada periode 1993-2004, terdapat sejumlah kegiatan yang mempertemukan berbagai klub/komunitas Honda Tiger dalam rangka mencapai 3 tujuan utama: (i) membentuk dan meningkatkan rasa persaudaraan dan solidaritas diantara sesama pemilik motor Honda Tiger, (ii) memberikan manfaat sosial yang positif dari keberadaan klub/komunitas motor Honda Tiger bagi masyarakat luas, dan (iii) meningkatkan kesadaran dan kedisiplinan para pemilik Honda Tiger terhadap keamanan dan keselamatan berkendara di jalan raya.
                </a>
            </div>
            <div style="text-align: justify;">
                <a>
                    <b>C. Komunitas</b><br>
                    Selayaknya wadah silaturahmi para biker, MBI pun sering mengadakan kegiatan riding ke beberapa daerah dan tempat yang direncanakan. Tidak sedikit juga kegiatan MBI dilakukan melalui kegiatan touring sambil diskusi tentang keislaman. Bahkan slogan MBI dalam menyemangati setiap perjalanan adalah Indahnya Touring Nikmatnya Kajian.


                </a>
            </div>
        </div>




</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->